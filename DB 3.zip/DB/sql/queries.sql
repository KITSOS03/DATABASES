SELECT f.festival_year, p.name AS payment_method, SUM(t.price) AS total_revenue FROM Ticket t JOIN Event e ON t.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id JOIN Payment_Method p ON t.payment_method_id = p.payment_method_id GROUP BY f.festival_year, p.name ORDER BY f.festival_year , p.name DESC;

SELECT a.artist_id, a.first_name, a.last_name, a.genre, CASE WHEN p.event_id IS NOT NULL THEN 'YES' ELSE 'NO' END AS festival_participation  FROM Artist a LEFT JOIN Performance p ON a.artist_id = p.artist_id LEFT JOIN Event e ON p.event_id = e.event_id LEFT JOIN Festival f ON e.festival_id = f.festival_id WHERE a.genre = 'rock' AND (f.festival_year = 2025 OR f.festival_year IS NULL) ORDER BY a.last_name, a.first_name;

SELECT a.artist_id, a.first_name, a.last_name, f.festival_id, f.name AS festival_name, f.festival_year, COUNT(p.performance_id) AS warm_up_appearances FROM Artist a JOIN Performance p ON a.artist_id = p.artist_id JOIN Performance_Type pt ON p.type_id = pt.type_id JOIN Event e ON p.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id WHERE pt.name = 'warm-up' GROUP BY a.artist_id, f.festival_id, f.festival_year HAVING COUNT(p.performance_id)>2 ORDER BY f.festival_year DESC, f.name, a.last_name, a.first_name ASC; 

SELECT 
    a.artist_id, 
    a.first_name, 
    a.last_name, 
    AVG(r.performance_score) AS avg_performance_score, 
    AVG(r.overall_score) AS avg_overall_score
FROM Artist a
JOIN Performance p ON a.artist_id = p.artist_id
JOIN Ticket t ON p.event_id = t.event_id AND t.visitor_id IS NOT NULL
JOIN Review r ON r.ticket_id = t.ticket_id
WHERE a.artist_id = 1
GROUP BY a.artist_id, a.first_name, a.last_name
ORDER BY a.last_name, a.first_name;

SELECT 
    a.artist_id, 
    a.first_name, 
    a.last_name, 
    AVG(r.performance_score) AS avg_performance_score, 
    AVG(r.overall_score) AS avg_overall_score
FROM Artist a
JOIN Performance p FORCE INDEX (idx_performance_artist) 
    ON a.artist_id = p.artist_id
JOIN Ticket t FORCE INDEX (idx_ticket_event) 
    ON p.event_id = t.event_id AND t.visitor_id IS NOT NULL
JOIN Review r FORCE INDEX (idx_review_ticket) 
    ON r.ticket_id = t.ticket_id
WHERE a.artist_id = 1
GROUP BY a.artist_id, a.first_name, a.last_name
ORDER BY a.last_name, a.first_name;

SELECT a.artist_id, a.first_name, a.last_name, a.birth_date, COUNT(p.performance_id) AS festival_appearances FROM Artist a JOIN Performance p ON a.artist_id = p.artist_id JOIN Event e ON p.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id WHERE TIMESTAMPDIFF(YEAR, a.birth_date, CURDATE() < 30) GROUP BY a.artist_id ORDER BY festival_appearances DESC LIMIT 5; 

SELECT 
    p.performance_id, 
    e.name AS event_name, 
    f.name AS festival_name, 
    f.festival_year, 
    AVG(r.overall_score) AS avg_review_score
FROM Ticket t
JOIN Event e ON t.event_id = e.event_id
JOIN Festival f ON e.festival_id = f.festival_id
JOIN Performance p ON p.event_id = e.event_id
JOIN Review r ON r.ticket_id = t.ticket_id
WHERE t.visitor_id = 2
GROUP BY p.performance_id, e.name, f.name, f.festival_year
ORDER BY f.festival_year DESC, f.name, e.name;

SELECT 
    p.performance_id, 
    e.name AS event_name, 
    f.name AS festival_name, 
    f.festival_year, 
    AVG(r.overall_score) AS avg_review_score
FROM 
    Ticket t FORCE INDEX (idx_ticket_event)
JOIN 
    Review r FORCE INDEX (idx_review_ticket) ON r.ticket_id = t.ticket_id
JOIN 
    Event e FORCE INDEX (PRIMARY) ON t.event_id = e.event_id
JOIN 
    Festival f FORCE INDEX (PRIMARY) ON e.festival_id = f.festival_id
JOIN 
    Performance p FORCE INDEX (idx_performance_event) ON p.event_id = e.event_id
WHERE 
    t.visitor_id = 2
GROUP BY 
    p.performance_id, e.name, f.name, f.festival_year
ORDER BY 
    f.festival_year DESC, f.name, e.name;
    
 SELECT f.name AS festival_name, f.festival_year, AVG(el.degree) AS avg_experience_level FROM Staff s JOIN Experience_Level el ON s.experience_level_id = el.experience_level_id JOIN Event e ON s.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id GROUP BY f.festival_id ORDER BY avg_experience_level ASC LIMIT 1; 
 
 SELECT s.staff_id, s.first_name, s.last_name, s.role_id FROM Staff s LEFT JOIN Event e ON s.event_id = e.event_id WHERE  e.date_time != '2025/08/06' OR e.event_id IS NULL; 
 
 WITH PerformancesPerVisitor AS (
    SELECT 
        t.visitor_id,
        YEAR(e.date_time) AS event_year,
        COUNT(DISTINCT p.performance_id) AS total_performances
    FROM 
        Ticket t
    JOIN 
        Event e ON t.event_id = e.event_id
    JOIN 
        Performance p ON p.event_id = e.event_id
    GROUP BY 
        t.visitor_id, event_year
    HAVING 
        total_performances > 3
),
MatchingVisitors AS (
    SELECT 
        a.visitor_id AS visitor1_id,
        b.visitor_id AS visitor2_id,
        a.event_year,
        a.total_performances
    FROM 
        PerformancesPerVisitor a
    JOIN 
        PerformancesPerVisitor b 
        ON a.total_performances = b.total_performances 
           AND a.event_year = b.event_year 
           AND a.visitor_id < b.visitor_id
)
SELECT 
    mv.event_year,
    mv.total_performances,
    v1.first_name AS visitor1_first_name,
    v1.last_name AS visitor1_last_name,
    v2.first_name AS visitor2_first_name,
    v2.last_name AS visitor2_last_name
FROM 
    MatchingVisitors mv
JOIN 
    Visitor v1 ON mv.visitor1_id = v1.visitor_id
JOIN 
    Visitor v2 ON mv.visitor2_id = v2.visitor_id
ORDER BY 
    mv.event_year, mv.total_performances DESC;


SELECT a1.genre AS genre_1, a2.genre AS genre_2, COUNT(*) AS pair_count FROM Performance p1 JOIN Artist a1 ON p1.artist_id = a1.artist_id JOIN Performance p2 ON p1.event_id = p2.event_id AND p1.artist_id != p2.artist_id JOIN Artist a2 ON p2.artist_id = a2.artist_id JOIN Event e ON p1.event_id = p2.event_id JOIN Festival f ON e.festival_id = f.festival_id WHERE a1.genre IS NOT NULL AND a2.genre IS NOT NULL AND a1.genre != a2.genre GROUP BY a1.genre, a2.genre ORDER BY pair_count DESC LIMIT 3;

SELECT a.artist_id, a.first_name, a.last_name, COUNT(DISTINCT e.festival_id) AS festival_participations FROM Artist a JOIN Performance p ON a.artist_id = p.artist_id JOIN Event e ON p.event_id = e.event_id GROUP BY a.artist_id, a.first_name, a.last_name HAVING festival_participations <= (SELECT MAX(festival_count) - 5 FROM (SELECT COUNT(DISTINCT e2.festival_id) AS festival_count FROM Artist a2 JOIN Performance p2 ON a2.artist_id = p2.artist_id JOIN Event e2 ON p2.event_id = e2.event_id GROUP BY a2.artist_id) AS sub) ORDER BY festival_participations DESC;

SELECT DATE(e.date_time) AS festival_day, sr.name AS staff_category, COUNT(DISTINCT s.staff_id) AS staff_requirement FROM Staff s JOIN Staff_Role sr ON s.role_id = sr.role_id JOIN Event e ON s.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id GROUP BY DATE(e.date_time), sr.name ORDER BY festival_day, staff_category;

SELECT a.artist_id, a.first_name, a.last_name, COUNT(DISTINCT l.continent) AS continents_participate FROM Artist a JOIN Performance p ON a.artist_id = p.artist_id JOIN Event e ON p.event_id = e.event_id JOIN Festival f ON e.festival_id = f.festival_id JOIN Location l ON f.location_id = l.location_id WHERE l.continent IS NOT NULL GROUP BY a.artist_id, a.first_name, a.last_name HAVING COUNT(DISTINCT l.continent) >= 3 ORDER BY continents_participate DESC;

WITH genre_year_counts AS (SELECT a.genre, YEAR(e.date_time) AS year, COUNT(*) AS appearances FROM Artist a JOIN Performance p ON a.artist_id = p.artist_id JOIN Event e ON p.event_id = e.event_id WHERE a.genre IS NOT NULL GROUP BY a.genre, YEAR(e.date_time) HAVING COUNT(*) >= 3)
SELECT g1.genre, g1.year AS year1, g2.year AS year2, g1.appearances FROM genre_year_counts g1 JOIN genre_year_counts g2 ON g1.genre = g2.genre AND g1.year + 1 = g2.year AND g1.appearances = g2.appearances ORDER BY g1.genre, g1.year;

SELECT v.first_name AS visitor_first_name, v.last_name AS visitor_last_name, a.first_name AS artist_first_name, a.last_name AS artist_last_name, SUM(r.overall_score) AS total_score FROM Review r JOIN Ticket t ON r.ticket_id = t.ticket_id JOIN Visitor v ON t.visitor_id = v.visitor_id JOIN Event e ON t.event_id = e.event_id JOIN Performance p ON e.event_id = p.event_id JOIN Artist a ON p.artist_id = a.artist_id WHERE r.overall_score IS NOT NULL GROUP BY v.visitor_id, a.artist_id ORDER BY total_score DESC LIMIT 5; 
    
    